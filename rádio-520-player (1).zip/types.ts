
export enum PlayerMode {
  VIDEO = 'VIDEO',
  AUDIO = 'AUDIO',
}
